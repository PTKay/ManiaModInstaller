This mod installer extracts, installs the mods, and repacks Data.rsdk using RSDKPack automaticaly, 
making mod instalation much easier.

The mods should all go to the Mods directory, each one with their own subfolder.
This release comes pre-packaged with the Saturn UI, the Playstation UI, the Sonic Discovery Title Screen mod, and the
best Mania mod of all times.

Intructions:
1 - Paste the contents of this zip into the game folder
2 - Paste mods in the Mods folder
3 - Run "ModInstaller.bat"
4 - You'll be greeted with a menu with several options. The one you probably want
is the "Install Mods" option, so pick that one by typing 1 and hitting Enter!
4.1 - There will be 3 prompts asking you what mods you want to install, meaning
you can install 3 mods at a time each time you open the program. If you want to
install more, just reopen ModInstaller.bat
5 - Wait until the mods are installed, and enjoy!

Mod folders cannot have spaces in their names (again). If they do, then enter the
name of the mod between "" (not tested, but should work).

There will probably be more updates for the ManiaModInstaller.
Since this release contains an automatic updater, you don't need to
do anything beside saying yes when you're prompted to update!


Credits:
RSDKPack by Skyth (while Sajid/K.T.E2399 and SuperSonic16 helped behind the curtains)
File name list (data.txt) by Slash
ManiaModInstaller by PTKickass
AutoUpdater code by SuperSonic16